﻿using System.Collections.Generic;

namespace Hearthstone
{
    public class test
    {
        }
}